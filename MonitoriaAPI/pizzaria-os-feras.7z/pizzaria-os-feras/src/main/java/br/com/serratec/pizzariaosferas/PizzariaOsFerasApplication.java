package br.com.serratec.pizzariaosferas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzariaOsFerasApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzariaOsFerasApplication.class, args);
	}

}
