package br.com.serratec.pizzariaserratec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SerratecRelacionamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SerratecRelacionamentosApplication.class, args);
	}

}
