package br.com.serratec.pizzariaserratec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerratecRelacionamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
